import { Component, OnInit, ɵSWITCH_TEMPLATE_REF_FACTORY__POST_R3__ } from '@angular/core';
import { LoginComponent } from '../login/login.component';
var alldataadminpanel;
declare var swal:any;
@Component({
  selector: 'app-adminpanel',
  templateUrl: './adminpanel.component.html',
  styleUrls: ['./adminpanel.component.scss']
})
export class AdminpanelComponent implements OnInit {
  Posts
  renderDataObject = { Posts: "", Accesslevels: "", Documents_accesslevels: "", Services: "" };
  memberData; allottoData; users_alloted_view
  constructor() { }
  callUrl(data2Post) {
    $.ajax({
      type: "post",
      url: "http://192.168.0.22/hrm-angular+php/phpfuns.php",
      //url: "http://192.168.0.34/hrm-angular+php/phpfuns.php",
      data: data2Post,
      success: (res, status, data) => {
        var idxFailure = res.indexOf("failure")
        var idxSuccess = res.indexOf("success")
        if (idxFailure > -1) { return }
        if (idxSuccess === -1) 

        switch (data2Post.mode) {
          case 'POST_MEMBERS':
            var postmembers = JSON.parse(res.substr(idxSuccess + 7))
            console.log(postmembers)
            this.viewmemberResponse("member_data", postmembers)
            return
          case 'ACCESSLEVELS_MEMBER':
            var doormembers = JSON.parse(res.substr(idxSuccess + 7))
            this.viewmemberResponse("member_data", doormembers)
            return
          case 'DOCUMENTS_ACCESSLEVELS_MEMBERS':
            var docmembers = JSON.parse(res.substr(idxSuccess + 7))
            this.viewmemberResponse("member_data", docmembers)
            return
          case 'SERVICES_MEMBERS':
            var servmembers = JSON.parse(res.substr(idxSuccess + 7))
            this.viewmemberResponse("member_data", servmembers)
            return
          case 'POST_ALLOT':swal("Post alloted","","success"); return
          case 'ACCESSLEVELS_ALLOT':swal("Door access alloted","","success"); return
          case 'DOCUMENTS_ACCESSLEVELS_ALLOT':swal("Document access alloted","","success"); return
          case 'SERVICES_ALLOT':swal("Service alloted","","success"); return
        }
      },
      error: (error) => { console.log("Error") }
    })
  }
  adminpanel(data) { alldataadminpanel = data; console.log(data) }
  ngOnInit() { }
  adminpanelnavclick(id) {
    $(".sectionViewdata").each((_, el) => {
      if (id.substr(8) == el.id) { $(el).show(); this.renderDataObject[el.id.substr(5)] = alldataadminpanel[el.id.substr(5)] }
      else if (id.substr(8) != el.id) { $(el).hide(); }
    })
  }
  viewandAllot(id, refrence) {
    switch (refrence) {
      case 'Postsview':
        this.callUrl({ mode: "POST_MEMBERS", data: JSON.stringify({ post: id }) })
        return
      case 'Doorview':
        this.callUrl({ mode: "ACCESSLEVELS_MEMBER", data: JSON.stringify({ access_levels: id }) })
        return
      case 'Documentview':
        this.callUrl({ mode: "DOCUMENTS_ACCESSLEVELS_MEMBERS", data: JSON.stringify({ documents_accesslevels: id }) })
        return
      case 'Serviceview':
        this.callUrl({ mode: "SERVICES_MEMBERS", data: JSON.stringify({ services: id }) })
        return
      case 'Postsallot':
        this.allottoData = { post: id }; this.userdetail_Allot('POST_ALLOT')
        return
      case 'Doorallot':
        this.allottoData = { access_levels: id }; this.userdetail_Allot('ACCESSLEVELS_ALLOT')
        return
      case 'Documentallot':
        this.allottoData = { documents_accesslevels: id }; this.userdetail_Allot('DOCUMENTS_ACCESSLEVELS_ALLOT')
        return
      case 'Serviceallot':
        this.allottoData = { services: id }; this.userdetail_Allot('SERVICES_ALLOT')
        return
    }
  }
  userdetail_Allot(key) {
    alldataadminpanel.Users.forEach(el => { el["key"] = key });
    this.users_alloted_view = alldataadminpanel.Users
    $(".sectionViewdata").each((_, el) => {
      if (el.id == 'Alloted_users') { $(el).show() }
      else if (el.id != 'Alloted_users') { $(el).hide() }
    })
  }
  finalAllotUsers(id, key) {
    this.allottoData["prid"] = id
    var a = { mode: key, data: JSON.stringify(this.allottoData) }
    console.log(a)
    this.callUrl({ mode: key, data: JSON.stringify(this.allottoData) })
  }
  viewmemberResponse(mode, data) {
    this.memberData = data
    $(".sectionViewdata").each((_, el) => {
      if (el.id == mode) { $(el).show() }
      else if (el.id != mode) { $(el).hide() }
    })
  }
  displayproperty(mode) {
    switch (mode) {
      case 'hideadminpanel': $("#Adminpanel_Component").hide(); $("#Heirarchy_Component").show(); return;
      case 'hideheirarchycomponent': $("#Heirarchy_Component").hide(); $("#Adminpanel_Component").show(); return;
    }
  }
}