<?php
print_r(time()."</br>\n".microtime(TRUE));

?>
